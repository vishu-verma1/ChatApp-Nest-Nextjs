import { Injectable, UnauthorizedException } from '@nestjs/common';
import { PassportStrategy } from '@nestjs/passport';
import { ExtractJwt, Strategy } from 'passport-jwt';
import { ConfigService } from '@nestjs/config';
import { Socket } from 'socket.io';

@Injectable()
export class JwtStrategy extends PassportStrategy(Strategy) {
  constructor(private configService: ConfigService) {
    const secretOrKey = configService.get<string>('JWT_SECRET');
    console.log('JWT_SECRET:', secretOrKey);
    if (!secretOrKey) {
      throw new Error('JWT_SECRET is not defined in the configuration');
    }
    super({
      jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
      secretOrKey,
      passReqToCallback: true,

    });

    
  }

  async validate(payload: any) {
    console.log(payload,"----------")
    if (!payload) {
      throw new UnauthorizedException();
    }
    // return { id: payload.sub, email: payload.email };
    return true;
  }

  static extractJwtFromSocket(client: Socket): string | null {
    try {
      const token = client.handshake.query.token as string;
      if (!token) {
        throw new Error('Token not found in handshake query');
      }
      return token;
    } catch (error) {
      console.error('Error extracting token from socket:', error.message);
      return null;
    }
  }
}

import {
  WebSocketGateway,
  SubscribeMessage,
  MessageBody,
  ConnectedSocket,
  OnGatewayConnection,
  OnGatewayDisconnect,
} from '@nestjs/websockets';
import { Socket } from 'socket.io';
import { ChatService } from './chat.service';
import { NotificationService } from 'src/notification/notification.service';
import { Client } from 'socket.io/dist/client';
import { UnauthorizedException, UseGuards } from '@nestjs/common';
import { JwtAuthGuard } from 'src/auth/guard/jwt.auth.guard';
import { JwtService } from '@nestjs/jwt';

@WebSocketGateway({ cors: { origin: '*' } })
export class ChatGateway implements OnGatewayConnection, OnGatewayDisconnect {
  constructor(
    private readonly chatService: ChatService,
    private readonly notificationService: NotificationService,
    private readonly jwtService: JwtService,
  ) {}

  private activeUsers = new Map();

  async handleConnection(client: Socket) {
    try {
      const token = client.handshake.query.token as string;
      if (!token) {
        throw new UnauthorizedException('No token provided');
      }
      const payload = this.jwtService.verify(token);
      client.data.user = { id: payload.sub, email: payload.email };
      console.log(
        `Client connected chatgatway: ${client.id} User: ${payload.email}`,
      );
    } catch (error) {
      console.error(`Connection error: ${error.message}`);
      client.disconnect();
    }
  }

  async handleDisconnect(client: Socket) {
    console.log(`Client disconnected: ${client.id}`);
    this.activeUsers.delete(client.id);
  }

  @SubscribeMessage('join')
  async handleJoin(
    @MessageBody() data: { userId: string },
    @ConnectedSocket() client: Socket,
  ) {
    console.log('data', data);
    this.activeUsers.set(client.id, data.userId);
    console.log(`User ${data.userId} joined with socket ID: ${client.id}`);
  }

  @SubscribeMessage('sendMessage')
  async handleMessage(
    @MessageBody()
    data: { senderId: string; receiverId: string; content: string },
    @ConnectedSocket() client: Socket,
  ) {
    if (!data.senderId || !data.receiverId || !data.content) {
      console.error('Invalid message data:', data);
      return;
    }

    console.log(
      `Message from ${data.senderId} to ${data.receiverId}: ${data.content}`,
    );

    const receiverSocketId = [...this.activeUsers.entries()].find(
      ([_, userId]) => userId === data.receiverId,
    )?.[0];

    const sender = await this.chatService.getUserById(data.senderId);
    if (!sender) {
      console.error('Sender not found:', data.senderId);
      return;
    }

    const savedMessage = await this.chatService.saveMessage(
      data.senderId,
      data.receiverId,
      data.content,
    );

    if (receiverSocketId) {
      client.to(receiverSocketId).emit('newNotification', {
        senderId: data.senderId,
        content: `New Message from ${sender.username}`,
      });

      const messages = await this.chatService.getMessage(
        data.senderId,
        data.receiverId,
      );
      client.to(receiverSocketId).emit('receiveMessage', messages);
    } else {
      //if user offline
      await this.notificationService.saveNotification(
        data.senderId,
        data.receiverId,
        `New Message from ${sender.username}`,
      );
    }
  }

  @SubscribeMessage('typing')
  handleTyping(
    @MessageBody() data: { senderId: string; receiverId: string },
    @ConnectedSocket() Client: Socket,
  ) {
    const receiverSocketId = this.activeUsers.get(data.receiverId);
    if (receiverSocketId) {
      Client.to(receiverSocketId).emit('userTyping', {
        senderId: data.senderId,
      });
    }
  }

  @SubscribeMessage('seenMessage')
  async handleSeenMessage(
    @MessageBody() data: { messageId: string },
    @ConnectedSocket() Client: Socket,
  ) {
    const { messageId } = data;
    const message = await this.chatService.markMessageAsSeen(messageId);
    const senderSocketId = [...this.activeUsers.entries()].find(
      ([_, userId]) => userId === message?.senderId,
    )?.[0];
    if (senderSocketId) {
      Client.to(senderSocketId).emit('message Seen Udated', {
        messageId: message?.id,
        isSeen: true,
      });
    }
  }

  @SubscribeMessage('sendImageMessage')
  async handleImageMessage(
    @MessageBody()
    data: {
      senderId: string;
      receiverId: string;
      imgurl: string;
      caption?: string;
    },
    @ConnectedSocket() Client: Socket,
  ) {
    const { senderId, receiverId, imgurl, caption } = data;
    if (!senderId || !receiverId || !imgurl) {
      console.error('Invalid image message data:', data);
      return;
    }
    const message = await this.chatService.saveMessage(
      senderId,
      receiverId,
      caption || ' ',
      imgurl,
    );

    const receiverSocketId = [...this.activeUsers.entries()].find(
      ([_, userId]) => userId === data.receiverId,
    )?.[0];

    if (receiverSocketId) {
      Client.to(receiverSocketId).emit('receive meessage', message);
    }
  }
}

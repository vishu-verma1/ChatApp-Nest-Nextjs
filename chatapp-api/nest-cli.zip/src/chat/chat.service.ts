import { Injectable } from '@nestjs/common';
import { InjectModel } from '@nestjs/sequelize';
import { Messages } from 'src/messages/models/messages.model';
import { User } from 'src/user/models/user.model';
import * as crypto from 'crypto';
import { ConfigService } from '@nestjs/config';

@Injectable()
export class ChatService {
  algorithm = 'aes-256-ctr';
  encryptionKey = '12345678901234567890123456789012';

  constructor(
    @InjectModel(User) private userModel: typeof User,
    @InjectModel(Messages) private messageModel: typeof Messages,
    private configService: ConfigService,
  ) {}

  encryptText(content: string): { iv: string; encryptedData: string } {
    // const encryptionKey = this.configService.get<string>('ENCRYPTION_KEY');
    const iv = crypto.randomBytes(16);
    const cipher = crypto.createCipheriv(
      this.algorithm,
      this.encryptionKey, //encryptionKey
      iv,
    );
    let encrypted = cipher.update(content, 'utf-8', 'hex');
    encrypted += cipher.final('hex');
    return { iv: iv.toString('hex'), encryptedData: encrypted };
  }

  decryptText(ivHex: string, encryptedData: string): string {
    if (!ivHex) {
      throw new Error('ivHex is undefined');
    }
    const iv = Buffer.from(ivHex, 'hex');
    const dcipher = crypto.createDecipheriv(
      this.algorithm,
      this.encryptionKey,
      iv,
    );
    let decrypted = dcipher.update(encryptedData, 'hex', 'utf-8');
    decrypted += dcipher.final('utf-8');
    return decrypted;
  }

  async getUserById(userId: string): Promise<User | null> {
    return this.userModel.findByPk(userId);
  }

  async saveMessage(senderId: string, receiverId: string, content: string, imgurl?:string) {
    const { iv, encryptedData } = this.encryptText(content);
    return await this.messageModel.create({
      senderId,
      receiverId,
      content: encryptedData,
      iv,
      imagrUrl:imgurl
    });
  }

  async getMessage(senderId: string, receiverId: string) {
    const messages = await this.messageModel.findAll({
      where: { senderId, receiverId },
      attributes: [
        'id',
        'content',
        'senderId',
        'iv',
        'receiverId',
        'createdAt',
      ],
      order: [['createdAt', 'ASC']],
    });

    return messages.map((message) => {
      const messageData = message.get({ plain: true });
      if (!messageData.iv) {
        throw new Error('iv is undefined in the message');
      }
      return {
        ...messageData,
        content: this.decryptText(messageData.iv, messageData.content),
      };
    });
  }

  async deleteMessages(messageId: string, userId: string) {
    const message = await this.messageModel.findOne({
      where: { id: messageId, senderId: userId },
    });

    if (!message) {
      throw new Error('message not found and Unauthorized');
    }

    message.isDeleted = true;
    message.save();
    return { message: 'message has been deleted successfully' };
  }

  async markMessageAsSeen(messageId:string){
    const message = await this.messageModel.findByPk(messageId);
    if(message){
      message.isSeen = true;
      await message.save();
      return message;

    }
    return null 
  }
}

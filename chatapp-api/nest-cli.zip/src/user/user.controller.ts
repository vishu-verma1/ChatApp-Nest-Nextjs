import {
  BadRequestException,
  Body,
  Controller,
  Get,
  Param,
  Post,
  Put,
  Req,
  UnauthorizedException,
  UseGuards,
} from '@nestjs/common';
import { SignInUserDto, UserDto } from 'src/dtos/user.dto';
import { UserService } from './user.service';
import {
  createUserSchema,
  signInSchema,
  updateUserSchema,
} from 'src/schemas/user.schema';
import { AuthService } from 'src/auth/auth.service';
import { JwtAuthGuard } from 'src/auth/guard/jwt.auth.guard';
import { Request } from 'express';

@UseGuards(JwtAuthGuard)
@Controller('user')
export class UserController {
  constructor(
    private authService: AuthService,
    private userService: UserService,
  ) {}

  @Put('update-user')
  async updateUser(@Body() userUpdateDto: UserDto) {
    const validation = updateUserSchema.safeParse(userUpdateDto);
    if (!validation.success) {
      throw new BadRequestException(validation.error.errors);
    }
  }

  
  @Get('profile')
  async getUserProfile(@Req() req: Request) {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer')) {
      throw new UnauthorizedException('Unvalid Credentials Please login');
    }

    const token = authHeader.split(' ')[1];
    const result = await this.userService.getingUser(token);

    if (!result) {
      throw new BadRequestException(result);
    }

    return result;
  }
}

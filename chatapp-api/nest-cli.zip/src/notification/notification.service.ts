import { Injectable } from '@nestjs/common';
import { Notification } from './models/notification.model';
import { InjectModel } from '@nestjs/sequelize';

@Injectable()
export class NotificationService {
    constructor(@InjectModel(Notification) private notificationModel: typeof Notification){}

    async saveNotification(senderId:string, receiverId:string, content:string){
        return await this.notificationModel.create({
            senderId,
            receiverId,
            content,
        })
    }

    async getNotification(receiverId:string){
        return await this.notificationModel.findAll({where:{receiverId, isRead:false}})
    }

    async markAsRead(notificationId:string){
        return await this.notificationModel.update({isReade:true},{where:{id:notificationId}})
    }
}

export class UserDto {
  username: string;
  email: string;
  password: string;
}

export class SignInUserDto {
  email: string;
  password: string;
}
